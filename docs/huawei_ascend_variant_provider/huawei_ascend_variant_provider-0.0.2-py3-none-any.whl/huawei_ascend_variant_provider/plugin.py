# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import cache
from typing import Protocol, runtime_checkable

from huawei_ascend_variant_provider.detect_cann import AscendEnvironment


@runtime_checkable
class VariantPropertyType(Protocol):
    @property
    def namespace(self) -> str: ...
    @property
    def feature(self) -> str: ...
    @property
    def value(self) -> str: ...


@dataclass(frozen=True)
class VariantFeatureConfig:
    name: str
    values: list[str]
    multi_value: bool = False


class AscendVariantFeatureKey:
    NPU_TYPE = "npu_type"
    DRIVER_VERSION = "driver_version"
    CANN_VERSION = "cann_version"

class AscendVariantPlugin:
    namespace = "ascend"
    dynamic = False

    @classmethod
    @cache
    def get_supported_configs(cls, context=None) -> list[VariantFeatureConfig]:
        keyconfigs: list[VariantFeatureConfig] = []
        env = AscendEnvironment.from_system()

        npu_type = os.environ.get("ASCEND_VARIANT_PROVIDER_FORCE_NPU_TYPE")
        if npu_type:
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.NPU_TYPE,
                    values=[npu_type],
                    multi_value=False
                )
            )
        else:
            detected_npu_types = [npu_type for _, npu_type in (env.npu_types if env else [])]
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.NPU_TYPE,
                    values=[detected_npu_types[0]] if detected_npu_types else [],
                    multi_value=False
                )
            )

        driver_version = os.environ.get("ASCEND_VARIANT_PROVIDER_FORCE_DRIVER_VERSION")
        if driver_version:
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.DRIVER_VERSION,
                    values=[driver_version],
                    multi_value=False
                )
            )
        else:
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.DRIVER_VERSION,
                    values=[f"{env.driver_version.major}.{env.driver_version.minor}" + 
                                (f".{env.driver_version.patch}" if env.driver_version and env.driver_version.patch is not None else "") + 
                                (f".rc{env.driver_version.rc}" if env.driver_version and env.driver_version.rc is not None else "")] 
                                if env and env.driver_version else [],
                    multi_value=False
                )
            )

        cann_version = os.environ.get("ASCEND_VARIANT_PROVIDER_FORCE_CANN_VERSION")
        if cann_version:
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.CANN_VERSION,
                    values=[cann_version],
                    multi_value=False
                )
            )
        else:
            keyconfigs.append(
                VariantFeatureConfig(
                    name=AscendVariantFeatureKey.CANN_VERSION,
                    values=[f"{env.cann_version.major}.{env.cann_version.minor}" + 
                                (f".{env.cann_version.patch}" if env.cann_version and env.cann_version.patch is not None else "") + 
                                (f".rc{env.cann_version.rc}" if env.cann_version and env.cann_version.rc is not None else "")] 
                                if env and env.cann_version else [],
                    multi_value=False
                )
            )
        
        return keyconfigs

    @classmethod
    @cache
    def get_all_configs(cls, context=None) -> list[VariantFeatureConfig]:
        return cls.get_supported_configs()


def main() -> int:
    """Print detected variant feature configs for quick local validation."""
    configs = AscendVariantPlugin.get_supported_configs()
    for config in configs:
        print(
            f"{AscendVariantPlugin.namespace} :: {config.name} :: "
            f"values={config.values}, multi_value={config.multi_value}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
